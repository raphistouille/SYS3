#include "stdio.h"

void lire(){
    char data[100];
    char os[4];
    int offset = read(0,data,100);
    sprintf(os,"%d",offset);
    write(2,os,strlen(os));
    write(1,data,offset);
}